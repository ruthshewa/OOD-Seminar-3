package se.kth.iv1350.seminar3.view;

public class ViewTest {

}
