package se.kth.iv1350.seminar3.dto;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

public class ItemDTOTest {
    private ItemDTO item;

    @BeforeEach
    public void setUp() {
        item = new ItemDTO("Test Item", 1, 100.0, 25.0, 10);
    }

    @AfterEach
    public void tearDown() {
        item = null;
    }

    @Test
    public void testGetItemID() {
        assertEquals(1, item.getItemID(), "Item ID should be 1");
    }

    @Test
    public void testGetItemName() {
        assertEquals("Test Item", item.getItemName(), "Item name should be 'Test Item'");
    }

    @Test
    public void testGetItemPrice() {
        assertEquals(100.0, item.getItemPrice(), "Item price should be 100.0");
    }

    @Test
    public void testGetItemVAT() {
        assertEquals(25.0, item.getItemVAT(), "Item VAT should be 25.0");
    }

    @Test
    public void testGetQuantity() {
        assertEquals(10, item.getQuantity(), "Item quantity should be 10");
    }

    @Test
    public void testSetQuantity() {
        item.setQuantity(20);
        assertEquals(20, item.getQuantity(), "Item quantity should be 20 after setting it to 20");
    }

    @Test
    public void testIncreaseQuantity() {
        item.increaseQuantity(5);
        assertEquals(15, item.getQuantity(), "Item quantity should be 15 after increasing by 5");
    }

    @Test
    public void testDecreaseQuantity() {
        item.decreaseQuantity(3);
        assertEquals(7, item.getQuantity(), "Item quantity should be 7 after decreasing by 3");
    }
}

