package se.kth.iv1350.seminar3.modell;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import se.kth.iv1350.seminar3.dto.ItemDTO;

public class SaleTest {

    private Sale sale;

    @BeforeEach
    public void setUp() {
        sale = new Sale();
    }

   /**
    * This test adds one item in the sale 
    */
    @Test
    public void testAddItem() {
        ItemDTO item = new ItemDTO("Apple", 1, 3.7, 0.12, 2);
        sale.addItem(item, 2);

        assertEquals(item, sale.getPurchasedItems().get(0));
    }

   
   

    


}
