package se.kth.iv1350.seminar3.controller;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import se.kth.iv1350.seminar3.dto.ItemDTO;

import se.kth.iv1350.seminar3.modell.Sale;

public class ControllerTest {
    private Controller controller;

    @BeforeEach
    public void setUp() {
        controller = new Controller();
        controller.startSale();
        
    }

    @AfterEach
    public void tearDown() {
        controller = null;
    }
    
   
   
    
    /**
     * Test to see if the startSale creates an object of the sale class
     */

    @Test
    public void testStartSaleIsInitilliazed() {
       
        controller.startSale();
       Sale theStateOfTheSale = controller.getCurrentSale();
      
        assertNotNull(theStateOfTheSale, "Sale should be initialized");
    }
    
    /**
     * Test to see if the startSale method creates a new sale object every time it is called on
     */

    @Test
    public void testStartSaleCreatesNewSaleObjectOnEveryCall() {
    	controller.startSale();
    	
    	Sale firstObject = controller.getCurrentSale();
    	
    	controller.startSale();
    	
    	Sale secondObject = controller.getCurrentSale();
    	assertNotSame(firstObject, secondObject, "The startSale does not create a new Sale object");
    }
    
    /**
     * This test when both parameters itemID and quantity are valid inputs
     */

    @Test
    public void testScanItemSuccesfully() {
        int itemID = 1;
        int quantity = 2;
        
        ItemDTO expected = new ItemDTO("Apple" ,itemID,10,2,1);
        
        ItemDTO item = controller.scanItem(itemID, quantity);
        assertNotNull(item, "Item can not be found in the inventorySystem or the purchasedlist");
        assertEquals(expected.getItemID(), item.getItemID(), "");
        assertEquals(quantity, item.getQuantity(), "Item quantity should match the scanned quantity");
    }
    
    
    
    /**
     * This test tests if one can scan more than one item and the items are different 
     */
    
    
    @Test
    public void testScanItemMultipleScansDifferentItems() {
        int firstItemID = 1;
        int quantityForTheFirstItem = 2;
        
        int secondItemID = 2;
        int quantityForTheSecondItem = 3;
        	
        
        ItemDTO expectedDTOForTheFirstItem = new ItemDTO("Apple" ,firstItemID,10,2,1);
        ItemDTO expectedDTOForTheSecondItem = new ItemDTO("Päron" ,secondItemID,10,2,1);
        
        ItemDTO firstItem = controller.scanItem(firstItemID, quantityForTheFirstItem );
        ItemDTO secondItem = controller.scanItem(secondItemID, quantityForTheSecondItem );
        
        assertNotNull(firstItem, "Item can not be found in the inventorySystem or the purchasedlist");
        assertNotNull(secondItem, "Item can not be found in the inventorySystem or the purchasedlist");
        assertNotEquals(expectedDTOForTheFirstItem.getItemName(), expectedDTOForTheSecondItem.getItemName(), "The Scanner has not scanned two different items");
      
    }
    
    
    /**
     * This test tests if one can scan an item with the quantity one without the cashier typing in the number
     */
    
    @Test
    public void testScanItemWithQuantityOne() {
    	
    	int itemID = 1;
    	
    	ItemDTO expected = new ItemDTO("Apple" ,itemID,10,2,1);
    	ItemDTO scannedItem = controller.scanItemWithQuantityOne(itemID);
    	
    	assertNotNull(scannedItem, "Item can not be found in the inventorySystem or the purchasedlist");
    	assertEquals(expected.getItemID(), scannedItem.getItemID(), "Scanning an item with the quantity one is not possible");
    	
    	
    }
   
    
    
 /**
  * Test ending the sale. An item needed to be added in the list otherwise the test will fail due to totalprice not being greater than 0 
  */

    @Test
    public void testEndSale() {
    	
    	int itemID = 1;
    	ItemDTO scannedItem = controller.scanItemWithQuantityOne(itemID);
    	
    	
        double totalPrice = controller.endSale();
        assertTrue(totalPrice > 0, "Total price should be greater than 0 after ending the sale");
    }
    
    
    
    @Test
    public void testPay() {
        
        int itemID = 1;
        int quantity = 2;
        controller.scanItem(itemID, quantity);
        
       
        controller.endSale();
        

        double amountPaid = 100.0;
        double discount = 10.0;
        String paymentMethod = "Cash";

        controller.pay(amountPaid, discount, paymentMethod);

        assertNotNull(controller, "Controller should not be null after payment");
    }

  

   
}

