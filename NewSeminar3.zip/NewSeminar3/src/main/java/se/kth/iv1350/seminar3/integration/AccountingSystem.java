package se.kth.iv1350.seminar3.integration;

import se.kth.iv1350.seminar3.dto.SaleDTO;

public class AccountingSystem {
	
	 public AccountingSystem(){


	    }


	/**
	     * Sends sale information to the accounting system. This method is used to update the accounting records.
	     * @param saleDTO The data transfer object containing necessary information to update the accounting system.
	     */
	    public void sendSaleInfo(SaleDTO saleDTO) {
	    	

	    }

}
