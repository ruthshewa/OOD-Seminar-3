package se.kth.iv1350.seminar3.integration;

public class DiscountRegister {

	
	
	
	public DiscountRegister() {
	}
}
