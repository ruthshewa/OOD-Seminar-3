package se.kth.iv1350.seminar3.modell;

import java.util.ArrayList;
import java.util.Random;

import se.kth.iv1350.seminar3.dto.ItemDTO;

public class Sale {
	
	private ArrayList<ItemDTO> purchased;
    private double runningCurrentTotalPrice;
    private int saleID;
    private double discountCurrentTotalPrice;

    /**
     * Constructs a Sale with a unique ID and initializes it.
     */
    public Sale() {
        this.saleID = generateRandomSaleID();
        this.purchased = new ArrayList<>();
        this.runningCurrentTotalPrice = 0; 
    }

    /**
     * Generates a random, non-negative Sale ID.
     * @return Randomly generated integer.
     */
    private int generateRandomSaleID() {
        Random random = new Random();
        return random.nextInt(Integer.MAX_VALUE);
    }


     /**
     * Adds a specified quantity of a new item to the purchased list.
     * @param itemDTO The item to add or update.
     * @param quantity The quantity of the item.
     */
    public void addItem(ItemDTO itemDTO, int quantity) {
        purchased.add(itemDTO);
        itemDTO.setQuantity(quantity);
        updateTotalPrice();
    }

    /**
     * Recalculates the total price of the sale based on the items and their quantities.
     */
    private void updateTotalPrice() {
        runningCurrentTotalPrice = 0;
        for (ItemDTO item : purchased) {
            runningCurrentTotalPrice += item.getItemPrice() * item.getQuantity();
        }
    }

     /**
     * Retrieves the list of items purchased.
     * @return List of items.
     */
    public ArrayList<ItemDTO> getPurchasedItems() {
        return purchased;
    }
    /**
     * @return unique Sale ID.
     */
    public int getSaleID() {
        return saleID;
    }
     /**
     * @return runningCurrentTotalPrice
     */

    public double getCurrentTotalPrice() {
        return runningCurrentTotalPrice;
    } 
    
    public double applyDiscount(double discountAmount) {

        discountCurrentTotalPrice = runningCurrentTotalPrice- discountAmount;
        return discountCurrentTotalPrice;
    }


}
