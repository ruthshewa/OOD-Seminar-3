package se.kth.iv1350.seminar3.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import se.kth.iv1350.seminar3.modell.Sale;

public class SaleDTO {
	private double snapshotOfTheCurrentTotalPrice;
    private ArrayList<ItemDTO> snapshotOfPurchasedItems;
    private final int saleDTOID;

    /**
     * Constructs a SaleDTO by copying values from the Sale object.
     * This ensures that the SaleDTO contains a snapshot of the sale's state at the time of creation,
     * preventing any further changes to affect this data.
     * 
     * @param sale The Sale object to copy data from.
     */
    public SaleDTO(Sale sale) {
        this.snapshotOfTheCurrentTotalPrice = sale.getCurrentTotalPrice();
        this.snapshotOfPurchasedItems = copyItems(sale.getPurchasedItems());
        this.saleDTOID = sale.getSaleID();
    }

    /**
     * Creates a deep copy of the list of purchased items  found in the Sale object.
     * @param purchased The original list of purchased items found in the Sale class.
     * @return A  copy of the list of the purchased items.
     */
    private ArrayList<ItemDTO> copyItems(ArrayList<ItemDTO> purchased) {
        ArrayList<ItemDTO> itemsCopy = new ArrayList<>(purchased.size());
        for (ItemDTO item : purchased) {
            itemsCopy.add(item);
        }
        return itemsCopy;
    }

    /**
     * 
     * This method now returns an unmodifiable list to prevent external modifications.
     * 
     * @return A list that is not volatile and a copy of the sale object list..
     */
    public List<ItemDTO> getTheListOfPurchasedItems() {
        return Collections.unmodifiableList(snapshotOfPurchasedItems);
    }

    /**
     * Gets the snapshot of the current total price at the time of DTO creation.
     * 
     * @return The total price of the sale when the DTO was created.
     */
    public double getTheCurrentTotalPrice() {
        return snapshotOfTheCurrentTotalPrice;
    }

    /**
     * Gets the unique identifier for the sale that this DTO represents.
     * 
     * @return The sale ID.
     */
    public int getSaleDTOID() {
        return saleDTOID;
    }


}
