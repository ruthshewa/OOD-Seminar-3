package se.kth.iv1350.seminar3.controller;
import se.kth.iv1350.seminar3.modell.Payment;
import se.kth.iv1350.seminar3.modell.Receipt;
import se.kth.iv1350.seminar3.modell.Sale;
import se.kth.iv1350.seminar3.dto.SaleDTO;
import se.kth.iv1350.seminar3.dto.ItemDTO;
import se.kth.iv1350.seminar3.integration.InventorySystem;
import se.kth.iv1350.seminar3.integration.AccountingSystem;
import se.kth.iv1350.seminar3.integration.Printer;
import se.kth.iv1350.seminar3.integration.DiscountRegister;


		
		
		/**
		 * The Controller class acts as the mediator between the view and the model.
		 * It handles user actions, fetches data from the model, and determines the response for the view.
		 */
		public class Controller {

		    private AccountingSystem accSys;
		    private DiscountRegister discountReg;
		    private InventorySystem invSys;
		    private Printer printer;
		    private Payment payment;
		    private Sale sale;
		    private Receipt receipt;
		    private int discountValue = 23;
		    private SaleDTO saleDTO;
		    private double currentTotalPriceBeforeDiscount;
		    private int oneItem = 1;

		    /**
		     * Creates a new instance, initializing all external system handlers.
		     */
		    public Controller() {
		        accSys = new AccountingSystem();
		        discountReg = new DiscountRegister();
		        invSys = new InventorySystem();
		        printer = new Printer();
		    }

		    /**
		     * Starts a new sale transaction.
		     */
		    public void startSale() {
		        sale = new Sale();
		    }
		    
		    
		    public Sale getCurrentSale() {
		        return sale;
		    }
		    
		    
		     /**
		     * If the item is not found in the sale, it fetches the itemDTO from the inventory system.  
		     * @param itemID The identifier of the item to search for.
		     * @param quantity The quantity of the item.
		     * @return ItemDTO The item that is found in the inventory system given the item identifier .
		     */
		    
		     
		    private ItemDTO fetchItemInfo(int itemID) {
		        return invSys.fetchIteminfo(itemID);
		    }

		    /**
		     * Updates the list of purchased items in the sale.
		     *
		     * @param itemDTO  The item that is added to the list.
		     * @param quantity  Is the given quantity of the item that is added to the list.
		     */
		    private void updateSale(ItemDTO itemDTO, int quantity) {
		        sale.addItem(itemDTO, quantity);
		    }
		    
		    /**
		     * The method scans an item and its quantity and returns the specified item from the inventory system.
		     *@param itemID The identifier of the item to add.
		     * @param quantity The number of units that is scanned of the specified item
		     * @return The specified item from the inventory system.
		     */
		    
		    public ItemDTO scanItem(int itemID, int quantity) {
		        ItemDTO itemDTO = fetchItemInfo(itemID);
		        updateSale(itemDTO, quantity);
		        return itemDTO;
		    }

		     /**
		     * The method handles scanning an item with a default quantity of one.
		     *
		     * @param itemID The identifier of the item to add.
		     * @return The ItemDTO of the added item.
		     */
		    public ItemDTO scanItemWithQuantityOne(int itemID) {
		        return scanItem(itemID, oneItem);
		    }
		    
		    /**
		     * Ends the current sale process.
		     * @return The calculated total price including tax.
		     */
		    public double endSale() {
		    	currentTotalPriceBeforeDiscount= sale.getCurrentTotalPrice();
		        return currentTotalPriceBeforeDiscount;
		    }

		     /**
		     * The payment transaction for the current sale occurs here. Any available discount is applied,
		     * the receipt is printed and the external systems are updated given the with the sale information.
		     *
		     * @param amountPaid the amount paid by the customer
		     * @param paymentMethod the method used for payment
		     * @param discount is the value that should be reduced from the totalprice of the current sale
		     */
		      
		  public void pay(double amountPaid, double discount, String paymentMethod) {
            
		    payment = new Payment(amountPaid, currentTotalPriceBeforeDiscount - discount, paymentMethod);
		    receipt = new Receipt(payment, sale);
		    printer.print(receipt);
		  	saleDTO = new SaleDTO(sale);
		    updateExternalSystems(saleDTO);
   
		  } 
		  
		  /**
		   * The customer asks for a discount.
		   * @param customerId is number sequence that uniquely identifies a customer.
		   * @return discount is the value that should be reduced from the totalprice of the sale
		   */


		    public double requestDiscount(int customerId) {
		         double discount= sale.applyDiscount(discountValue);
		         return discount;

		     }
		     /**
		     * Updates external systems with the details of the current sale.
		     * Sends sale information to the inventory and accounting systems for processing.
		     */
		    private void updateExternalSystems(SaleDTO saleDTO) {
		        invSys.sendSaleInfo(saleDTO);
		        accSys.sendSaleInfo(saleDTO);
		    }

		    
		}

